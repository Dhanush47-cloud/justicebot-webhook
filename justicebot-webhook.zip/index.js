const express = require("express");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.post("/webhook", (req, res) => {
  const intent = req.body.queryResult.intent.displayName;
  
  let responseText = "Sorry, I didn't understand your request.";

  if (intent === "LegalHelpIntent") {
    responseText = "You have the right to free legal aid in certain cases.";
  } else if (intent === "FileGrievance") {
    responseText = "Please visit your nearest district legal services authority to file a grievance.";
  }

  res.json({
    fulfillmentText: responseText,
  });
});

app.get("/", (req, res) => {
  res.send("JusticeBot Webhook is running.");
});

app.listen(PORT, () => {
  console.log(`Webhook server is listening on port ${PORT}`);
});
